import pygame as pg


class Particle:
    def __init__(self, pos: list, radius, color, minusx, minusy, diminishvalue, type=None):
        self.pos = pos
        self.radius = radius
        self.color = color
        self.minusx, self.minusy = minusx, minusy
        self.diminish_value = diminishvalue
        self.type = type
        self.rect = pg.Rect(self.pos[0], self.pos[1], self.radius, self.radius)

    def update_draw(self, window):
        self.radius -= self.diminish_value
        self.rect = pg.Rect(self.pos[0], self.pos[1], self.radius, self.radius)
        # pg.draw.rect(window, (255, 0, 0), self.rect)
        pg.draw.circle(window, self.color, self.pos, self.radius)
