# import pygame as pg


class Entity:
    def __init__(self):
        self.is_passive = False
        self.is_aggressive = False
        self.is_active = False

    @property
    def set_active(self):
        self.is_active = True

        return self

    @property
    def set_passive(self):
        self.is_passive = True
        return self

    @property
    def set_aggressive(self):
        self.is_aggressive = True
        return self

    def kill(self):
        self.is_active = False

        return self
