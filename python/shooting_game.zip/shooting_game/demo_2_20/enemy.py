import pygame as pg
import math
from data.scripts.entity import Entity


class Enemy(Entity):
    def __init__(self, x, y, width, height, color=(255, 0, 0), health=100, id=''):
        super().__init__()
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.health = health
        self.id = id
        self.rect = pg.Rect(self.x, self.y, self.width, self.height)
        self.image = pg.image.load(r'data\images\enemy_sprite.png').convert()
        self.image.set_colorkey((255, 255, 255))
        self.image = pg.transform.scale(self.image, (self.width, self.height))

    def straight_engage(self, targetx, targety, speed):
        radians = math.atan2(targety - self.y, targetx - self.x)

        dx = math.cos(radians) * speed
        dy = math.sin(radians) * speed

        self.x += dx
        self.y += dy

        self.rect = pg.Rect(self.x, self.y, self.width, self.height)

    def draw(self, window: pg.Surface):
        if self.is_active:
            if 15 < self.health < 50:
                if self.id != 'boss_med':
                    self.width, self.height = self.health, self.health
                    self.image = pg.transform.scale(self.image, (self.health, self.health))
                    self.image.set_alpha(self.health * 5)
            self.rect = pg.Rect(self.x, self.y, self.width, self.height)

            # pg.draw.rect(window, self.color, self.rect)
            window.blit(self.image, (self.x, self.y))
