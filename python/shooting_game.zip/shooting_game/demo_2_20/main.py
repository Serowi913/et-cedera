import random

import pygame as pg
import sys

from particle import Particle
from constants import *
from enemy import Enemy

pg.mixer.init()
pg.font.init()


def handle_explosion_particles(lst, window, playerrect, health):
    for explosion in lst:
        for particle in explosion:
            particle.radius -= particle.diminish_value
            particle.pos[0] -= particle.minusx
            particle.pos[1] -= particle.minusy
            if particle.radius <= 0:
                if particle in explosion:
                    explosion.remove(particle)
            # print(health)
            # print(particle.type)
            if particle.type == 'health':
                if particle.rect.colliderect(playerrect):
                    health += 3
                    explosion.remove(particle)

            particle.update_draw(window)
        if len(explosion) == 0:  # If the sub-list is empty, remove it from explosion_particles_lst
            lst.remove(explosion)
    return health


def handle_radius_attack(lst, window):  # Handles and draws Radius attack particles
    for projectile in lst:
        projectile.radius -= projectile.diminish_value
        projectile.pos[0] -= projectile.minusx
        projectile.pos[1] -= projectile.minusy
        if projectile.rect.x < -20 or projectile.rect.x > WINDOW_SIZE[0]:
            lst.remove(projectile)
        elif projectile.rect.y < -20 or projectile.rect.y > WINDOW_SIZE[1]:
            lst.remove(projectile)
        projectile.update_draw(window)


def handle_projectiles(projectileslst, window):  # Handles and draws Player-Shot Particles (Projectiles)
    for projectile in projectileslst:
        projectile.radius -= projectile.diminish_value
        projectile.pos[0] -= projectile.minusx
        projectile.pos[1] -= projectile.minusy
        if projectile.radius <= 0:
            projectileslst.remove(projectile)
        else:
            projectile.update_draw(window)


def spawn_enemy(enemieslst, dimensions=(50, 50)):
    rx = random.randint(0, 1)  # Makes 50 50 chances
    ry = random.randint(0, 1)

    if rx:
        ex = random.randint(WINDOW_SIZE[1], WINDOW_SIZE[1] + 100)
    else:
        ex = random.randint(-150, -50)

    if ry:
        ey = random.randint(WINDOW_SIZE[0], WINDOW_SIZE[0] + 100)
    else:
        ey = random.randint(-150, -50)

    enemieslst.append(Enemy(ex + random.randint(-50, 50), ey + random.randint(-50, 50), dimensions[0], dimensions[1],
                            health=dimensions[0] * 2, id="boss_med" if dimensions[0] == 100 else None).set_active)


def main():
    ROOT_WINDOW = pg.display.set_mode(WINDOW_SIZE)  # (900, 600)
    WINDOW = pg.Surface(WINDOW_SIZE)
    CLOCK = pg.time.Clock()
    pg.mouse.set_visible(False)

    BACKGROUND0 = pg.image.load(r'data\images\background0.png').convert()
    BACKGROUND0 = pg.transform.scale(BACKGROUND0, WINDOW_SIZE)
    BACKGROUND1 = pg.image.load(r'data\images\background1.png').convert()
    BACKGROUND1 = pg.transform.scale(BACKGROUND1, WINDOW_SIZE)
    BACKGROUND2 = pg.image.load(r'data\images\background2.png').convert()
    BACKGROUND2 = pg.transform.scale(BACKGROUND2, WINDOW_SIZE)
    BACKGROUND3 = pg.image.load(r'data\images\background3.png').convert()
    BACKGROUND3 = pg.transform.scale(BACKGROUND3, WINDOW_SIZE)

    BACKGROUNDS = [BACKGROUND0, BACKGROUND1, BACKGROUND2, BACKGROUND3]

    current_bg = 0
    current_bg_alpha = 255
    next_bg_alpha = 0

    PLAYER_SPRITE = pg.image.load(r'data\images\player_sprite.png').convert()
    PLAYER_SPRITE.set_colorkey(WHITE)
    PLAYER_SPRITE_OVERHEAT = pg.image.load(r'data\images\player_sprite_overheat.png').convert()
    PLAYER_SPRITE_OVERHEAT.set_colorkey(WHITE)
    player_sprite_overheat_aplha = 1
    player_rect = pg.Rect(WINDOW_CENTERX - 19, WINDOW_CENTERY - 19, 39, 38)

    crosshair_img = pg.image.load(r'data\images\crosshair.png').convert()
    crosshair_img = pg.transform.scale(crosshair_img, (25, 25))
    crosshair_img.set_colorkey(WHITE)

    radius_shot_img_1 = pg.image.load(r'data\images\radius_shot.png').convert()
    radius_shot_img_1 = pg.transform.scale(radius_shot_img_1, (24, 24))
    radius_shot_img_1.set_colorkey(WHITE)

    radius_shot_img_2 = radius_shot_img_1.copy()

    radius_shot_img_3 = radius_shot_img_1.copy()

    player_sprite = PLAYER_SPRITE
    playerx, playery = WINDOW_SIZE[0] / 2, WINDOW_SIZE[1] / 2

    player_shoot_sound = pg.mixer.Sound(r'data\audio\fx\player_shoot.wav')
    shooting_sound_channel = pg.mixer.find_channel()

    player_hurt_sound = pg.mixer.Sound(r'data\audio\fx\player_hurt.wav')

    enemy_explode_sound = pg.mixer.Sound(r'data\audio\fx\enemy_explode.wav')

    radius_shot_sound = pg.mixer.Sound(r'data\audio\fx\radius_attack_sound.wav')

    stats_fnt = pg.font.SysFont('erasdemiitc', 20)

    projectile_particles_lst = []

    explosion_particles_lst = []

    radius_attack_particles = []

    radius_attack_locs = {  # Dict for storing the diminshx and diminishy values for the 16 radius attack particles
        0: (5, 0),
        1: (5, 2.5),
        2: (5, 5),
        3: (2.5, 5),
        4: (0, 5),
        5: (-2.5, 5),
        6: (-5, 5),
        7: (-5, 2.5),
        8: (-5, 0),
        9: (-5, -2.5),
        10: (-5, -5),
        11: (-2.5, -5),
        12: (0, -5),
        13: (2.5, -5),
        14: (5, -5),
        15: (5, -2.5)
    }

    enemies_lst = [

        # Enemy(50, WINDOW_SIZE[1] - 70, 50, 50).set_active

    ]

    UNIVERSAL_ENEMY_SPEED = 3

    dir_rng_x = 0
    dir_rng_y = 0

    angle = 0

    shots_fired = 0

    health = 30

    kill_count = 0

    streak = 0

    num_radius_shots = 3

    num_cursor_shots = 500

    num_enemies_spawned = 0

    num_cursor_shots_bar = pg.Rect(WINDOW_SIZE[0] - 40, 50, 15, num_cursor_shots)

    has_cursor_shot = False

    reset_num_cursor_shots = True

    w_down = False
    s_down = False
    a_down = False
    d_down = False

    shooting = False

    cursor_shooting = False

    running = True

    while running:
        ROOT_WINDOW.fill(BLACK)
        ROOT_WINDOW.blit(WINDOW, (0, 0))
        WINDOW.fill(BG_COLOR)

        # if angle == 0:
        #     current_bg = 0
        # elif angle == 90:
        #     current_bg = 1
        # elif angle == 180:
        #     current_bg = 2
        # elif angle == 270:
        #     current_bg = 3

        current_bg = kill_count % 4

        try:
            WINDOW.blit(BACKGROUNDS[current_bg], ORIGIN)
        except IndexError:
            WINDOW.blit(BACKGROUNDS[0], ORIGIN)

        for e in pg.event.get():
            if e.type == pg.QUIT:
                sys.exit()

            if e.type == pg.KEYDOWN:
                if e.key == pg.K_w or e.key == pg.K_UP:
                    w_down = True
                if e.key == pg.K_s or e.key == pg.K_DOWN:
                    s_down = True
                if e.key == pg.K_a or e.key == pg.K_LEFT:
                    a_down = True
                if e.key == pg.K_d or e.key == pg.K_RIGHT:
                    d_down = True

                if e.key == pg.K_SPACE:
                    shooting = True
                    shooting_sound_channel.play(player_shoot_sound, -1)

                if e.key == pg.K_q:
                    if has_cursor_shot:
                        cursor_shooting = not cursor_shooting

                if e.key == pg.K_f:
                    if num_radius_shots > 0:
                        num_radius_shots -= 1
                        radius_shot_sound.play()
                        for i in range(0, 16):  # Creates radius attack particles
                            minx, miny = radius_attack_locs[i]
                            radius_attack_particles.append(Particle(pos=[WINDOW_CENTERX, WINDOW_CENTERY],
                                                                    radius=15,
                                                                    color=(0, 0, 100),
                                                                    minusx=minx,
                                                                    minusy=miny,
                                                                    diminishvalue=0.02))

            if e.type == pg.KEYUP:
                if e.key == pg.K_w or e.key == pg.K_UP:
                    w_down = False
                if e.key == pg.K_s or e.key == pg.K_DOWN:
                    s_down = False
                if e.key == pg.K_a or e.key == pg.K_LEFT:
                    a_down = False
                if e.key == pg.K_d or e.key == pg.K_RIGHT:
                    d_down = False

                if e.key == pg.K_SPACE:
                    shooting_sound_channel.pause()
                    shooting = False

        if shooting:
            if -32 <= dir_rng_x <= 32:
                if a_down:
                    dir_rng_x += 1
                if d_down:
                    dir_rng_x -= 1
            else:
                if dir_rng_x < 0:
                    dir_rng_x = -31
                if dir_rng_x > 0:
                    dir_rng_x = 31

            if -32 <= dir_rng_y <= 32:
                if w_down:
                    dir_rng_y += 1
                if s_down:
                    dir_rng_y -= 1
            else:
                if dir_rng_y < 0:
                    dir_rng_y = -31
                if dir_rng_y > 0:
                    dir_rng_y = 31

            color = random.randint(0, 100)
            shots_fired += 1
            player_sprite_overheat_aplha += 1.5
            UNIVERSAL_ENEMY_SPEED = 3
            if cursor_shooting:
                if num_cursor_shots > 0:
                    num_cursor_shots -= 1
                    mx, my = pg.mouse.get_pos()
                    dx = (mx - WINDOW_CENTERX) / 8
                    dy = (my - WINDOW_CENTERY) / 8
                    projectile_particles_lst.append(Particle(
                        pos=[playerx + player_sprite.get_width() / 8 - 5, playery + player_sprite.get_height() / 8 - 5],
                        radius=10,
                        color=(color, color, color),
                        minusx=-dx + random.randint(-3, 3),
                        minusy=-dy + random.randint(-3, 3),
                        diminishvalue=0.09))
                    dir_rng_x = dx + random.randint(-3, 3)
                    dir_rng_y = dy + random.randint(-3, 3)
                    num_cursor_shots_bar = pg.Rect(WINDOW_SIZE[0] - 40, 50, 15, num_cursor_shots)
                    UNIVERSAL_ENEMY_SPEED = 2

                else:
                    cursor_shooting = False
                    has_cursor_shot = False
                    reset_num_cursor_shots = True

            else:
                projectile_particles_lst.append(Particle(
                    pos=[playerx + player_sprite.get_width() / 8 - 5, playery + player_sprite.get_height() / 8 - 5],
                    radius=10,
                    color=(color, color, color),
                    minusx=dir_rng_x + random.randint(-3, 3),
                    minusy=dir_rng_y + random.randint(-3, 3),
                    diminishvalue=0.09))
        else:
            UNIVERSAL_ENEMY_SPEED = 3

        handle_projectiles(projectile_particles_lst, WINDOW)

        """
        
        EXPLOSION PARTICLES
        
        Structured so that the main list 'explosion_particles_lst' holds sub lists 'explosion' which hold the explosion
        particles for each enemy. 
        
        """
        health = handle_explosion_particles(explosion_particles_lst, WINDOW, player_rect, health)

        for enemy in enemies_lst:  # RADIUS ATTACK PARTICLES
            for particle in radius_attack_particles:
                if enemy.rect.colliderect(particle.rect):
                    if enemy.id == 'boss_med':
                        enemy.health -= 50
                    else:
                        kill_count += 1
                        streak += 1
                        enemy.kill()

                        explosion_particles_lst.append([])
                        for i in range(random.randint(5, 20)):
                            explosion_particles_lst[-1].append(
                                Particle(pos=[enemy.rect.center[0], enemy.rect.center[1]],
                                         radius=random.randint(15, 20),
                                         color=(random.randint(80, 120), 50, 50),
                                         # (100, 50, 50)
                                         minusx=random.randint(-5, 5),
                                         minusy=random.randint(-5, 5),
                                         diminishvalue=0.05))

                        if enemy in enemies_lst:
                            enemies_lst.remove(enemy)
                            enemy_explode_sound.play()

            for particle in projectile_particles_lst:
                if enemy.rect.colliderect(particle.rect):
                    if enemy.health <= particle.radius:
                        enemy.kill()
                        kill_count += 1
                        streak += 1
                        if kill_count % 10 == 0:
                            if num_radius_shots < 3:
                                num_radius_shots += 1

                        explosion_particles_lst.append([])
                        for i in range(random.randint(5, 20)):
                            r = True if random.randint(1, 10) == 5 else False
                            explosion_particles_lst[-1].append(
                                Particle(pos=[enemy.rect.center[0], enemy.rect.center[1]],
                                         radius=random.randint(15, 20),
                                         color=HEALTH_PARTICLE_COLOR if r else (random.randint(80, 120), 50, 50),
                                         # (100, 50, 50)
                                         minusx=random.randint(-5, 5),
                                         minusy=random.randint(-5, 5),
                                         diminishvalue=0.05,
                                         type="health" if r else ''))

                        if enemy in enemies_lst:
                            enemies_lst.remove(enemy)
                            enemy_explode_sound.play()
                    else:
                        enemy.health -= particle.radius
                    projectile_particles_lst.remove(particle)

            if enemy.rect.colliderect(player_rect):
                if enemy.id == 'boss_med':
                    if int(health / 5) > 1:  # Makes sure that the plays health divided by 5 is greater than one; health should only ever be an int
                        health -= int(health / 5)
                        player_hurt_sound.play(loops=2)
                        enemy.kill()
                        if enemy in enemies_lst:
                            enemies_lst.remove(enemy)
                    else:  # If the player's health divided by 5 is less than 1
                        health = 0

                else:  # If the enemy isn't a medium boss, decreases the health as normal (by 1)
                    health -= 1
                    streak = 0
                    enemy.kill()
                    player_hurt_sound.play()
                    if enemy in enemies_lst:
                        enemies_lst.remove(enemy)

            enemy.straight_engage(WINDOW_CENTERX - 25, WINDOW_CENTERY - 25, UNIVERSAL_ENEMY_SPEED)
            enemy.draw(WINDOW)

        handle_radius_attack(radius_attack_particles, WINDOW)

        player_sprite = pg.transform.rotate(PLAYER_SPRITE, angle)
        WINDOW.blit(player_sprite,
                    (playerx - int(player_sprite.get_width() / 2), playery - int(player_sprite.get_height() / 2)))

        if player_sprite_overheat_aplha >= 1:
            player_sprite_overheat_aplha -= 1
        player_sprite_overheat = pg.transform.rotate(PLAYER_SPRITE_OVERHEAT, angle)
        player_sprite_overheat.set_alpha(player_sprite_overheat_aplha)
        WINDOW.blit(player_sprite_overheat,
                    (playerx - int(player_sprite.get_width() / 2), playery - int(player_sprite.get_height() / 2)))

        angle += 6
        if angle >= 360:
            angle = 0

        if angle == 0:
            spawn_enemy(enemies_lst)
            num_enemies_spawned += 1
            if num_enemies_spawned % 20 == 0 and num_enemies_spawned != 0:
                spawn_enemy(enemies_lst, dimensions=(100, 100))

        if streak % 15 == 0 and streak != 0:
            has_cursor_shot = True
            if reset_num_cursor_shots:
                num_cursor_shots = 500
                reset_num_cursor_shots = False

        if health == 0:
            sys.exit(f"KILLS: {kill_count}")

        health_bar = pg.Rect(10, 10, 15, health * 2)
        pg.draw.rect(WINDOW, (180, 0, 0), health_bar)
        health_txt = stats_fnt.render(f"HEALTH: {health}", False, STATS_COLOR)
        WINDOW.blit(health_txt, (30, 10))

        kill_count_txt = stats_fnt.render(f"KILL_COUNT: {kill_count}", False, STATS_COLOR)
        WINDOW.blit(kill_count_txt, (30, 30))

        streak_txt = stats_fnt.render(f'{streak}x', False, (17 * streak if 255 >= 17 * streak else 255, 0, 0))
        WINDOW.blit(streak_txt, (30, 50))

        WINDOW.blit(radius_shot_img_1, (20, WINDOW_SIZE[1] - 30))
        WINDOW.blit(radius_shot_img_2, (60, WINDOW_SIZE[1] - 30))
        WINDOW.blit(radius_shot_img_3, (100, WINDOW_SIZE[1] - 30))
        if num_radius_shots == 0:
            radius_shot_img_1.set_alpha(25 * (kill_count % 10))
            radius_shot_img_2.set_alpha(0)
            radius_shot_img_3.set_alpha(0)
        elif num_radius_shots == 1:
            radius_shot_img_1.set_alpha(255)
            radius_shot_img_2.set_alpha(25 * (kill_count % 10))
            radius_shot_img_3.set_alpha(0)
        elif num_radius_shots == 2:
            radius_shot_img_1.set_alpha(255)
            radius_shot_img_2.set_alpha(255)
            radius_shot_img_3.set_alpha(25 * (kill_count % 10))
        elif num_radius_shots == 3:
            radius_shot_img_1.set_alpha(255)
            radius_shot_img_2.set_alpha(255)
            radius_shot_img_3.set_alpha(255)

        if has_cursor_shot:
            WINDOW.blit(crosshair_img, (
            WINDOW_SIZE[0] - crosshair_img.get_width() - 10, WINDOW_SIZE[1] - crosshair_img.get_height() - 10))
            pg.draw.rect(WINDOW, (50, 50, 50), num_cursor_shots_bar)

        if cursor_shooting:
            # pg.draw.circle(WINDOW, (200, 0, 0), pg.mouse.get_pos(), 8)
            WINDOW.blit(crosshair_img, (
            pg.mouse.get_pos()[0] - crosshair_img.get_width(), pg.mouse.get_pos()[1] - crosshair_img.get_height()))

        # print(radius_attack_particles)
        # print(explosion_particles_lst)
        # print(projectile_particles_lst)

        pg.display.set_caption(
            f"FPS: {CLOCK.get_fps()} | SHOTS_FIRED: {shots_fired} | NUM_ENEMIES_SPAWNED: {num_enemies_spawned}")
        pg.display.update()
        CLOCK.tick(FRAME_RATE)


if __name__ == '__main__':
    main()
